https://github.com/hive-ci/test-runner/blob/master/rakefile


# HIVE NOTES
# Current Hive: http://10.241.93.32:3000/projects/2

# sudo apt-get -y install openjdk-8-jdk wget unzip
# sudo add-apt-repository ppa:cwchien/gradle
# sudo apt-get update
# sudo apt-get install gradle
#
# sudo add-apt-repository ppa:maarten-fonville/android-studio
# sudo apt-get update
# sudo apt-get install android-studio
#

